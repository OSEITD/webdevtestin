<?php
// Placeholder for Supabase config and fetch helpers
?>
